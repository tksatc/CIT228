from django.apps import AppConfig


class TaskMastersConfig(AppConfig):
    name = 'task_masters'
